import {useState} from "react"
import TodoBoard from "./components/TodoBoard";

function App() {
  const [inputValue, setInputValue] = useState('')
  const [todoList, setTodoList] = useState([])             // 누적되는 초기값은 빈 배열 값

  const addItem = (e) => {
    e.preventDefault();
    console.log("추가하는 값 : ", inputValue)               // 추가하는 입력값
    setTodoList([...todoList, inputValue])    
    console.log("누적되는 값 : ", todoList)                 // 누적되는 값
  }

  return (
    <>
      <div className='container w-50'>
        <h1 className='mt-5'>오늘의 할일 : TodoList</h1>
        <form className='mt-5'>
          <div className='d-flex justify-content-center'>
            <input 
              type='text' 
              name="todo" id="todo" 
              className='form-control' 
              placeholder='오늘의 할일을 적어보세요' onChange={(e) => setInputValue(e.target.value)}
            ></input>
            <div className='w-25 ms-3'>
               <button className='btn btn-primary' onClick={addItem}>추가</button>
           </div>
         </div>
        <div className='form-text my-3' id='todoHelp'>오늘의 할일을 적고 버튼을 누르면 리스트에 추가됩니다.</div>

        <TodoBoard todoList={todoList} />         

      </form>
      </div>
    </>
  );
}

export default App;
