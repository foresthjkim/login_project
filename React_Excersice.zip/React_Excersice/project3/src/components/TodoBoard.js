import React from 'react'
import TodoItem from './TodoItem'

const TodoBoard = (props) => {
  return (
    <>
        <h1 className='mt-5 text-primary-emphasis'>TodoList</h1>
        {props.todoList.map((item)=><TodoItem item={item} />)}
        <TodoItem />
    </>
  )
}

export default TodoBoard
