// rafce 입력하면 아래 자동 생성
import React from 'react'

const TodoItem = (props) => {
  return (
    <div className='border-0 border-bottom p-4'>{props.item}</div>
  )
}

export default TodoItem
