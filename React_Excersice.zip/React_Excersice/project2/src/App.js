import React, {useState} from 'react';
import TodoBoard from './components/TodoBoard';
// import Todoitem from './components/Todoitem';

function App() {
  const [inputValue, setInputValue] = useState('')    // InputValue 값이 아직 refresh가 안되는 상태
  const [todoList, setTodoList] = useState([])        // InputValue 입력 값을 출력하기 위한 state 지정

  const addItem = (e) => {
    e.preventDefault();
    console.log("추가되는 값 : ", inputValue)
    setTodoList([...todoList, inputValue])          // 기존값을 유지하고 inputValue값을 추가한다.
    console.log("누적되는 값 : ", todoList)          // 배열로 console에 나온다.

  }
  return (
    <>
      <div className='container w-50'>
        <h1 className='mt-5'>오늘의 할일 : TodoList</h1>
        <form className='mt-5'>
          <div className='d-flex justify-content-center'>
            <input 
              type='text' 
              name='todo'
              className="form-control" 
              placeholder='오늘의 할일을 적어보세요'
              onChange={(e) => setInputValue(e.target.value)}
            ></input>

            <div className='w-25 ms-3'>
              <button className='btn btn-primary'onClick={addItem}>추가</button>
            </div>
          </div>
          <div className='form-text my-3'>오늘의 할일을 적고 버튼을 누르면 리스트에 추가 됩니다.</div>
        </form>
         {/* InputValue를 출력하기 위하여 TodoBoard components(TodoBoard.js)를 가져온다. */}
         {/* 그리고 TodoBoard.js 파일안에 Todoitem.js 컴포넌트가 실행되도록 추가한다. */}
        
        <TodoBoard todoList={todoList}/> 
        {/* todoList에게  */}
                    
      </div>
    </>
  );
}

export default App;
