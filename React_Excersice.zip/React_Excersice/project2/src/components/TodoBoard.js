import React from 'react'
import Todoitem from './Todoitem'

const TodoBoard = (props) => {
    console.log("todoBoard",props.todoList)
  return (
    <>
        <h1 className='mt-5 text-primary-emphasis'>TodoList</h1>
        {/* todoList.map: 배열값을 하나씩 꺼내서, item에 입력된 값을 Todoitem 에 넘겨준다 */}
        {props.todoList.map((item)=> <Todoitem item={item}/>)}
         <Todoitem />
    
    </>
  )
}

export default TodoBoard
