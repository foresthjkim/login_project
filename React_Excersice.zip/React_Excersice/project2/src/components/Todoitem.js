import React from 'react'

const Todoitem = (props) => {
  return (
    <div className='boarder-0 boarder-bottom p04'>
        {props.item}
    </div>
  )
}

export default Todoitem
