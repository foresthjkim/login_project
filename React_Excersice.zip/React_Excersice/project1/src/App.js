import './App.css';
import { useState } from 'react';

// 컴포넌트는 화면을 구성하는 독립적인 자기만이 구조와 역할을 가짐(부품처럼 만들어서 조합하는 형식)
// 버튼 하나, 입력창 하나, 헤더, 풋터 이런것들이 모두 컴포넌트
// 컴포넌트 이름은 반드시 대문자로 시작해야 함(예:Box.js)
// 컴포넌트는 함수, Return, <div> </div> 구조임(예:Box.js참조)
// props : 컴포넌트에 값을 전달하는 데이터 (부모가 자식에게 전달하는 하는 방식)
// state : 컴포넌트의 상태를 관리하면, 변경되면 화면에 바로 반영됨


function App() {
  let counter = 0;
  // 백단에서는 버튼 클릭할때마다 1씩 증가하지만, 화면에서는 0 refresh 값이 보임/그래서 useState 사용
  // const [변수명, set변수명과 동일하게 (함수)명] = useState(초기값);
  const [counter2,setCounter2] = useState(0);
  const increase = () => {
    counter = counter + 1;
    setCounter2(counter2 + 1)
    console.log("일반변수 : ",counter)  
    console.log("state 변수 : ",counter2)     
  }

  return (                          
    <>                              
      <div className='container'>
        <p className='my-5'>일반변수 : {counter}</p>
        <p className='my-5'>state변수 : {counter2}</p>
        <button className='btn btn-primary' onClick={increase}>클릭</button>

      </div>
    </>
  );

}

export default App;
