import './App.css';
import Box from './component/Box';

// 컴포넌트는 화면을 구성하는 독립적인 자기만이 구조와 역할을 가짐(부품처럼 만들어서 조합하는 형식)
// 버튼 하나, 입력창 하나, 헤더, 풋터 이런것들이 모두 컴포넌트
// 컴포넌트 이름은 반드시 대문자로 시작해야 함(예:Box.js)
// 컴포넌트는 함수, Return, <div> </div> 구조임(예:Box.js참조)
// props : 컴포넌트에 값을 전달하는 데이터

function App() {
  return (
    <div className="App">
      <Box subject="리액트 모던웹개발" num={1} />
      <Box subject="SQL입문" num={2}/>
      <Box subject="GIT, GitHub" num={3}/>
      
    </div>
  );
}

export default App;
