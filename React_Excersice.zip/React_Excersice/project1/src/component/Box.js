// rafce 입력 후 엔터를 치면 아래 import 및 Box 컴포넌트 구조 자동입력해 줌
import React from 'react'

const Box = (props) => {
    console.log("props", props)
  return (
    <div className='box'>
        <h2>베스트 셀러{props.num}</h2>
        <p>{props.subject}</p>
    </div>
  )
}

export default Box
