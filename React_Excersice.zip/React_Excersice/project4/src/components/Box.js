import React from 'react'

const Box = (props) => {
  console.log(props)
  
  let result;
  if(props.title === "Computer" && props.result !== 'tie' && props.result !== null) {
    result = props.result === "win" ? "lost" : "win"
  }
  else {
    result = props.result
  }
   
  return (
    <>
        <div className={`p-5 border border-secondary border-2 text-center position-relative ${result}`}>
            <h2>{props.title}</h2>
            {/* <img src='/images/scissors.png' alt='가위' width={150}></img> */}
            {/* 가위 바위 보 이미지를 선택했을때, 선택한 항목을 가져오기 위함 - props(부모->자식에게 넘겨줌): 
            props.item &&: 초기값 null (App.js에서 useState(null))이 무시하고 선택한 이미지를 적용해라  */}
            {/* <img src={props.item && props.item.img} alt='가위' width={150}></img> */}
            <img src={props.item ? props.item.img : "/images/scissors.png"} alt='가위' width={150}></img>
            {props.item && <div className={`bg-secondary text-white py-1 px-5 result ${result}div`}>{props.item && props.item.name},{result}</div>}   
        </div>

    </>
  )
}

export default Box
