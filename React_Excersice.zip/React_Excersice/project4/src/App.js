import { useState } from "react";
import "./App.css";
import Box from "./components/Box";

// 이미지 준비하기
const choice = {
  scissors : {
    name : "Scissors",
    img : "/images/scissors.png"
  },
  rock : {
    name : "Rock",
    img : "/images/rock.png"
  },
  paper : {
    name : "Paper",
    img : "/images/paper.png"
  }

}

function App() {
  const[userSelect, setUserSelect] = useState(null)
  const[computerSelect, setComputerSelect] = useState(null)
  const [result, setResult]= useState(null)

  const play = (userChoice) => {
    console.log("선택됨!!!", userChoice)
    setUserSelect(choice[userChoice])
    let computerChoice = randomChoice()
    setComputerSelect(computerChoice)
    setResult(judgement(choice[userChoice],computerChoice))
  }

  const judgement = (user, computer) => {
    console.log("user : ", user, "computer : ", computer)

    // 경우의 수 : 
    // 비김: user == computer
    // User가 이김: user == scissors, computer==paper
    // User가 이김: user == rock, computer==scissors
    // User가 이김: user == paper, computer==rock
    if(user.name === computer.name) return "tie"
    else if(user.name === "Scissors") return computer.name === "Paper"? "win" : "lost"
    else if(user.name === "Rock") return computer.name === "Scissors"? "win" : "lost"  
    else if(user.name === "Paper") return computer.name === "Rock"? "win" : "lost" 
    }

  const randomChoice = () => {
    let itemArray = Object.keys(choice)
    console.log("키값을 배열로 : ", itemArray)

    let randomItem = Math.floor(Math.random()*itemArray.length);
    console.log("랜덤한 값 : ",randomItem);
    let final = itemArray[randomItem]
    console.log("최종값 : ", final)
    return choice[final]
  }

  return (
    <>
    <div className="container text-center">
      <h1 className="mt-5">가위 바위 보 게임</h1>
      <h4 className="my-3 text-success">가위, 바위, 보 이미지를 클릭하면 게임이 시작 됩니다.</h4>
      <div className="row gx-3">
        <div className="col">
          {/* Box for User: Box.js  */}
          <Box item = {userSelect} title='User' result={result} />
        </div>
          {/* Box for Computer */}
        <div className="col">
          <Box item = {computerSelect} title='Computer' result={result} />
        </div>
      </div>
   
        <div className="my-3">
          {/* // 리엑트는 스스로 체크하기 위하여 자동으로 2번 실행해서 가져오기 때문에 "=>play()함수를 사용해야 함"  */}
            <img onClick={() => play("scissors")} src='/images/scissors.png' alt='가위' width={30}></img>
            <img onClick={() => play("rock")} src='/images/rock.png' alt='바위' width={30} className="mx-3"></img>
            <img onClick={() => play("paper")} src='/images/paper.png' alt='보' width={30}></img>
        </div>

        <div className="p-2 w-100 bg-secondary mx-auto text-center text-white fw-bold">
          이미지를 클릭하면 게임을 시작합니다.</div>

    </div>
    </>
  );
}

export default App;


